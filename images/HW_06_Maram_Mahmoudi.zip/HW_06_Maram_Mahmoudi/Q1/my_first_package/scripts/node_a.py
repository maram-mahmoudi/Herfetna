#!/usr/bin/env python3

import rospy
from turtlesim.srv import Spawn
from geometry_msgs.msg import Twist
import random


STARTING_RANGE_MIN = 0.5
STARTING_RANGE_MAX = 10.5

rospy.init_node('spawned_turtle')
rospy.wait_for_service('/spawn')
spawn_turtle = rospy.ServiceProxy('/spawn', Spawn)

# joyTurtle
joyTurtle = spawn_turtle(random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), 0, "joyTurtle")
rospy.Publisher('joyTurtle/cmd_vel', Twist, queue_size=10)

# keyTurtle
joyTurtle = spawn_turtle(random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), 0, "keyTurtle")
rospy.Publisher('keyTurtle/cmd_vel', Twist, queue_size=10)

# targetTurtle
targetTurtle = spawn_turtle(random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), 0, "targetTurtle")
rospy.Publisher('targetTurtle/cmd_vel', Twist, queue_size=10)


# enemy_turtle and its random movements 
enemyTurtle = spawn_turtle(random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), 0, "enemyTurtle")
enemy_vel_pub=rospy.Publisher('enemyTurtle/cmd_vel', Twist, queue_size=10)
rate = rospy.Rate(10)  # 10 Hz

while not rospy.is_shutdown():
    enemy_vel = Twist()
    enemy_vel.linear.x = random.uniform(-1, 3)  
    enemy_vel.angular.z = random.uniform(-4, 7)  
    enemy_vel_pub.publish(enemy_vel)
    rate.sleep()


if __name__ == '__main__':
    rospy.spin()