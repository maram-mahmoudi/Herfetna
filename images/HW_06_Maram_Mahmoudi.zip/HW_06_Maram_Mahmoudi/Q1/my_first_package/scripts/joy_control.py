#!/usr/bin/env python3

import rospy
import threading
import time
from std_msgs.msg import String
from geometry_msgs.msg import Twist
#from sensor_msgs.msg import Joy
import serial 

ser = serial.Serial('/dev/ttyUSB0', 57600) 

my_cmd_vel = Twist()
cmd_vel_sub =""

#def thread_function(name):
#    global cmd_vel_sub 
#    cmd_vel_sub = rospy.Publisher('joyTurtle/cmd_vel', Twist, queue_size=10)
#    print("Thread %s: starting", name)
#    while not rospy.is_shutdown():       
#        print("=========================================================")
#        print("%s",(my_cmd_vel))
#        print("=========================================================")
#        cmd_vel_sub.publish(my_cmd_vel)
#        time.sleep(0.1)

 

def callback_joy(data):
   # my_cmd_vel.linear.x=data.axes[1]
   # my_cmd_vel.angular.z=data.axes[0]
   # print ("--------------------------------------------")
   # print (my_cmd_vel)
   # print ("--------------------------------------------")
   # cmd_vel_sub.publish(my_cmd_vel)

    # read input values from serial port
    input_str = ser.readline().decode().strip()
    input_list = input_str.split(',')
    x = float(input_list[0])
    z = float(input_list[1])

    # update cmd_vel
    my_cmd_vel.linear.x = x
    my_cmd_vel.angular.z = z
    
    # publish cmd_vel
    cmd_vel_sub.publish(my_cmd_vel)

def listener():
    global cmd_vel_sub
    rospy.Subscriber('joyTurtle/cmd_vel', serial, callback_joy)
    cmd_vel_sub = rospy.Publisher('joyTurtle/cmd_vel', Twist, queue_size=10)
     

if __name__ == '__main__':
    rospy.init_node('my_game', anonymous=True)
    
    listener()
#    x = threading.Thread(target=thread_function, args=(1,))
#    x.start()
    rospy.spin()
