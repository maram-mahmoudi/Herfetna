#!/usr/bin/env python3

import rospy
import threading
import time
from std_msgs.msg import String
from geometry_msgs.msg import Twist

key_cmd_vel = Twist()

def thread_function(name):
    pub = rospy.Publisher('keyTurtle/cmd_vel', Twist, queue_size=10)
    print("Thread %s: starting", name)
    while not rospy.is_shutdown():       
        print("%s",(key_cmd_vel))
        pub.publish(key_cmd_vel)
        time.sleep(0.1)

 

def callback_key(data):
    rospy.loginfo(rospy.get_caller_id() + "I heard %s", data.data)

   #key callback code
def listener():
    rospy.Subscriber('keyturtle', String, callback_key)

     

if __name__ == '__main__':
    rospy.init_node('my_game', anonymous=True)
    
    listener()
    x = threading.Thread(target=thread_function, args=(1,))
    x.start()
    rospy.spin()
