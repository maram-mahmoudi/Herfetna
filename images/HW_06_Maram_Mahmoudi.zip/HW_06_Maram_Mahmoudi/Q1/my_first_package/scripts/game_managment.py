#!/usr/bin/env python3

import rospy
import random
from turtlesim.srv import Spawn, Kill
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import turtlesim.srv

JOY_SCORE = -1
KEY_SCORE = 0
#SPEED_FACTOR =1

joy_x = 0 ;joy_y = 0; key_x = 0; key_y = 0; target_x = 0; target_y = 0; enemy_x =0; enemy_y =0

def joy_callback(data):
    global joy_x, joy_y 
    joy_x= data.x
    joy_y= data.y
    
def key_callback(data): 
    global key_x, key_y 
    key_x= data.x
    key_y= data.y 

def enemey_callback(data):
    global enemy_x, enemy_y 
    enemy_x= data.x
    enemy_y= data.y
    
def target_callback(data):
    global target_x, target_y  
    target_x= data.x
    target_y= data.y
      
def turtle_kill(killed_name):
    rospy.wait_for_service('kill')
    killer=rospy.ServiceProxy('kill', turtlesim.srv.Kill)
    
    try:
        killer(killed_name)
    except rospy.ServiceException as e:
        print("Service call failed: {}".format(e))
        
        
def target_respawn():
    
    STARTING_RANGE_MIN = 0.5
    STARTING_RANGE_MAX = 10.5
    
    rospy.wait_for_service('/spawn')
    spawn_turtle = rospy.ServiceProxy('/spawn', Spawn)
    
    spawn_turtle(random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), random.uniform(STARTING_RANGE_MIN, STARTING_RANGE_MAX), 0, "targetTurtle")
"""
def reduce_speed(turtle_name):  
   
    key_twist = Twist()
    joy_twist = Twist()
    global SPEED_FACTOR
    SPEED_FACTOR = 0.5 
    
    #add if statment to reduce according to the turtle name
    if(turtle_name == 'joyTurtle'):
        joy_pub=rospy.Publisher('joyTurtle/cmd_vel', Twist, queue_size=10)
        joy_twist.linear.x *= SPEED_FACTOR
        joy_twist.angular.z *= SPEED_FACTOR
    if(turtle_name == 'keyTurtle'):
        key_pub=rospy.Publisher('keyTurtle/cmd_vel', Twist, queue_size=10) 
        key_twist.linear.x *= SPEED_FACTOR
        key_twist.angular.z *= SPEED_FACTOR

    # publish the modified twist messages
    joy_pub.publish(joy_twist)
    key_pub.publish(key_twist)

"""
def game_managment(): 

    turtle_kill('turtle1')

    global joy_x, joy_y, key_x, key_y, enemy_x, enemy_y, target_x, target_y
    global JOY_SCORE
    global KEY_SCORE
    
    PENALTY = 2
    tolerance = 0.5 
    
    rospy.init_node('manager_node')

    rospy.Subscriber('joyTurtle/pose', Pose, joy_callback)
    rospy.Subscriber('keyTurtle/pose', Pose, key_callback)  
    rospy.Subscriber('enemyTurtle/pose', Pose, enemey_callback)
    rospy.Subscriber('targetTurtle/pose', Pose, target_callback)
    
    rate = rospy.Rate(1) # 1hz

    while not rospy.is_shutdown():
        #if target position is equal joy turtle, kill target and +1 to joy score
        if(abs(target_x - joy_x ) <= tolerance and abs(target_y - joy_y ) <= tolerance ):
            turtle_kill('targetTurtle')
            JOY_SCORE +=1 
            print("Joy score is: %s" % str(JOY_SCORE))
            print("Key score is: %s" % str(KEY_SCORE))
            print("-----------------------\n")


            target_respawn()
            #rospy.spin()

        #if target position is equal to key turtle, kill target and +1 to key score
        if(abs(target_x - key_x ) <= tolerance and abs(target_y - key_y ) <= tolerance ):
            turtle_kill('targetTurtle')
            KEY_SCORE +=1 
            print("Joy score is: %s" % str(JOY_SCORE))
            print("Key score is: %s" % str(KEY_SCORE))
            print("-----------------------\n")
            target_respawn()
           # rospy.spin()
        
        #if enemy is touched by joy player, the player loses points
        if(abs(enemy_x-joy_x) <= tolerance and abs(enemy_y-joy_y) <= tolerance ):
            JOY_SCORE -= PENALTY
            #reduce_speed('joyTurtle')
            print("OPST JOY!!!")
            print("Joy score is: %s" % str(JOY_SCORE))
            print("Key score is: %s" % str(KEY_SCORE))
            print("-----------------------\n")

        #if enemy is touched by key player, the player loses points
        if(abs(enemy_x-key_x) <= tolerance and abs(enemy_y-key_y) <= tolerance ):
            KEY_SCORE -= PENALTY
           # reduce_speed('keyTurtle')
            print("OPST KEY!!!")
            print("Joy score is: %s" % str(JOY_SCORE))
            print("Key score is: %s" % str(KEY_SCORE))
            print("-----------------------\n")
            
        rate.sleep()
    rospy.spin()

if __name__ =='__main__':
    game_managment()
